﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PokerGame.BusinessLogic;
using PokerGame.Domain;
using System.Linq;

namespace PokerGameLibTest
{
    [TestClass]
    public class WinnersTest
    {
        [TestMethod]
        public void TestOnePairBeatsHighCard()
        {
            var pokerGameBusinessLogic = new PokerGameBusinessLogic();
            var pokerPlayer1 = new PokerPlayer();
            var pokerPlayer2 = new PokerPlayer();

            List<PokerPlayer> pokerPlayers = new List<PokerPlayer>();
            pokerPlayers.Add(pokerPlayer1);
            pokerPlayers.Add(pokerPlayer2);

            pokerPlayer1.HandInformation = new PokerGame.HandInformation();
            pokerPlayer1.HandInformation.CardHand = PokerGame.Enums.CardHand.HighCard;

            pokerPlayer2.HandInformation = new PokerGame.HandInformation();
            pokerPlayer2.HandInformation.CardHand = PokerGame.Enums.CardHand.OnePair;

            var winner = pokerGameBusinessLogic.GetWinners(pokerPlayers).Single();
            Assert.AreEqual(winner, pokerPlayer2);
            Assert.AreEqual(winner.HandInformation.CardHand, PokerGame.Enums.CardHand.OnePair);
        }

        public void TestThreeKindBeatsOnePair()
        {
            var pokerGameBusinessLogic = new PokerGameBusinessLogic();
            var pokerPlayer1 = new PokerPlayer();
            var pokerPlayer2 = new PokerPlayer();

            List<PokerPlayer> pokerPlayers = new List<PokerPlayer>();
            pokerPlayers.Add(pokerPlayer1);
            pokerPlayers.Add(pokerPlayer2);

            pokerPlayer1.HandInformation = new PokerGame.HandInformation();
            pokerPlayer1.HandInformation.CardHand = PokerGame.Enums.CardHand.OnePair;

            pokerPlayer2.HandInformation = new PokerGame.HandInformation();
            pokerPlayer2.HandInformation.CardHand = PokerGame.Enums.CardHand.ThreeOfKind;

            var winner = pokerGameBusinessLogic.GetWinners(pokerPlayers).Single();
            Assert.AreEqual(winner, pokerPlayer2);
            Assert.AreEqual(winner.HandInformation.CardHand, PokerGame.Enums.CardHand.ThreeOfKind);
        }
        public void TestFlushBeatsThreeKind()
        {
            var pokerGameBusinessLogic = new PokerGameBusinessLogic();
            var pokerPlayer1 = new PokerPlayer();
            var pokerPlayer2 = new PokerPlayer();

            List<PokerPlayer> pokerPlayers = new List<PokerPlayer>();
            pokerPlayers.Add(pokerPlayer1);
            pokerPlayers.Add(pokerPlayer2);

            pokerPlayer1.HandInformation = new PokerGame.HandInformation();
            pokerPlayer1.HandInformation.CardHand = PokerGame.Enums.CardHand.ThreeOfKind;

            pokerPlayer2.HandInformation = new PokerGame.HandInformation();
            pokerPlayer2.HandInformation.CardHand = PokerGame.Enums.CardHand.Flush;

            var winner = pokerGameBusinessLogic.GetWinners(pokerPlayers).Single();
            Assert.AreEqual(winner, pokerPlayer2);
            Assert.AreEqual(winner.HandInformation.CardHand, PokerGame.Enums.CardHand.Flush);
        }


    }
}
