﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PokerGame.BusinessLogic;
using PokerGame.Domain;
using PokerGame.Enums;
using PokerGame.Models;

namespace PokerGameLibTest
{
    [TestClass]
    public class HandEvaluationTest
    {
        [TestMethod]
        public void PlayerHasOnePairOfKings()
        {
            var pokerGameBusinessLogic = new PokerGameBusinessLogic();
            var pokerPlayer1 = new PokerPlayer();

            List<PokerPlayer> pokerPlayerList = new List<PokerPlayer>();
            pokerPlayerList.Add(pokerPlayer1);

            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.King, CardSuit = CardSuit.Club });
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Eight, CardSuit = CardSuit.Club });
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.King, CardSuit = CardSuit.Diamond});
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Four, CardSuit = CardSuit.Heart });
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Ace, CardSuit = CardSuit.Spade });

            pokerGameBusinessLogic.EvaluatePlayersHand(pokerPlayerList);

            Assert.AreEqual(pokerPlayer1.HandInformation.CardHand, CardHand.OnePair);
            Assert.AreEqual(pokerPlayer1.HandInformation.CardRank, CardRank.King);
        }

        [TestMethod]
        public void PlayerHasFlush()
        {
            var pokerGameBusinessLogic = new PokerGameBusinessLogic();
            var pokerPlayer1 = new PokerPlayer();

            List<PokerPlayer> pokerPlayerList = new List<PokerPlayer>();
            pokerPlayerList.Add(pokerPlayer1);

            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Ten, CardSuit = CardSuit.Club });
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Eight, CardSuit = CardSuit.Club });
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Two, CardSuit = CardSuit.Club });
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Jack, CardSuit = CardSuit.Club });
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Six, CardSuit = CardSuit.Club });

            pokerGameBusinessLogic.EvaluatePlayersHand(pokerPlayerList);

            Assert.AreEqual(pokerPlayer1.HandInformation.CardHand, CardHand.Flush);
            Assert.AreEqual(pokerPlayer1.HandInformation.CardRank, CardRank.Jack);
        }

        [TestMethod]
        public void PlayerThreeKindOfEight()
        {
            var pokerGameBusinessLogic = new PokerGameBusinessLogic();
            var pokerPlayer1 = new PokerPlayer();

            List<PokerPlayer> pokerPlayerList = new List<PokerPlayer>();
            pokerPlayerList.Add(pokerPlayer1);

            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.King, CardSuit = CardSuit.Club });
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Eight, CardSuit = CardSuit.Club });
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Eight, CardSuit = CardSuit.Diamond });
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Eight, CardSuit = CardSuit.Heart });
            pokerPlayer1.PokerHand.Add(new Card { CardRank = CardRank.Ace, CardSuit = CardSuit.Spade });

            pokerGameBusinessLogic.EvaluatePlayersHand(pokerPlayerList);

            Assert.AreEqual(pokerPlayer1.HandInformation.CardHand, CardHand.ThreeOfKind);
            Assert.AreEqual(pokerPlayer1.HandInformation.CardRank, CardRank.Eight);
        }
    }
}
