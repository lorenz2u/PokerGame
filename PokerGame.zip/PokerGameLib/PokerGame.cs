﻿using PokerGame.BusinessLogic;
using PokerGame.Domain;
using PokerGame.Enums;
using PokerGame.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PokerGame
{
    public class PokerGame
    {
        private List<Card> carddeck = new List<Card>();
        private List<PokerPlayer> players = new List<PokerPlayer>();
        private IPokerGameBusinessLogic pokerGameBusinessLogic = null;

        public PokerGame(IPokerGameBusinessLogic pokerGameBusinessLogic)
        {
            this.pokerGameBusinessLogic = pokerGameBusinessLogic;

            foreach (var suit in Enum.GetValues(typeof(CardSuit)))
            {
                foreach (var rank in Enum.GetValues(typeof(CardRank)))
                {
                    carddeck.Add(new Card { CardRank = (CardRank)rank, CardSuit = (CardSuit)suit });
                }
            }
        }

        public List<PokerPlayer> PlayGame()
        {
            //ShuffleCards();
            carddeck = CardDeck.ShuffleCards(carddeck);

            //DealCards();
            DealCards.DealPlayerCards(players, carddeck);

            //EvaluatePokerHand
            //winners = new PokerGameBusinessLogic();
            pokerGameBusinessLogic.EvaluatePlayersHand(players);

            var winningplayers = pokerGameBusinessLogic.GetWinners(players); 
            return winningplayers;
        }
              
        
        public void AddPlayers( string player)
        {
            players.Add(new PokerPlayer { Name = player });
        }
    }
}
