﻿
namespace PokerGame.Enums
{
    public enum CardSuit
    {
        Heart = 'H',
        Diamond = 'D',
        Spade = 'S',
        Club = 'C'
    }
}
