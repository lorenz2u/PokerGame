﻿
namespace PokerGame.Enums
{
    public enum CardHand
    {
        HighCard = 0,
        OnePair = 1,
        ThreeOfKind = 2,
        Flush = 3
    }
}
