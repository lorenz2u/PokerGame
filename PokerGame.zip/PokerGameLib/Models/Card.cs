﻿using PokerGame.Enums;

namespace PokerGame.Models
{
    public class Card
    {
        public CardRank CardRank { get; set; }
        public CardSuit CardSuit { get; set; }
    }
}
