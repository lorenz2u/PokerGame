﻿using PokerGame.Enums;

namespace PokerGame
{
    public class HandInformation
    {
        public CardHand CardHand { get; set; }
        public CardRank CardRank { get; set; }
    }
}
