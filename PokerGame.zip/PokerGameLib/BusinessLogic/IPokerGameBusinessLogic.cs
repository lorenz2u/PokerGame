﻿using PokerGame.Domain;
using System.Collections.Generic;

namespace PokerGame.BusinessLogic
{
    public interface IPokerGameBusinessLogic
    {
        void EvaluatePlayersHand(List<PokerPlayer> players);

        List<PokerPlayer> GetWinners(List<PokerPlayer> players);
    }
}
