﻿using PokerGame.Domain;
using PokerGame.Enums;
using PokerGame.Models;
using System.Collections.Generic;
using System.Linq;

namespace PokerGame.BusinessLogic
{
    public class PokerGameBusinessLogic : IPokerGameBusinessLogic
    {

        public void EvaluatePlayersHand(List<PokerPlayer> players)
        {
            foreach (var player in players)
            {
                HandInformation handinfo = new HandInformation();

                handinfo = EvaluateHand(player.PokerHand);

                player.HandInformation = handinfo;
            }

        }
        public List<PokerPlayer> GetWinners(List<PokerPlayer> players)
        {
            var highesthandtype = players.Max(m => m.HandInformation.CardHand);

            var winnerplayers = players.Where(s => s.HandInformation.CardHand == highesthandtype).ToList();

            if (winnerplayers.Count > 1)
            {
                var highestrankhand = winnerplayers.Max(w => w.HandInformation.CardRank);
                winnerplayers = winnerplayers.Where(p => p.HandInformation.CardRank == highestrankhand).ToList();
            }

            return winnerplayers;
        }

        public HandInformation EvaluateHand(List<Card> cardlist)
        {
            var SuitCount = cardlist.Select(x => x.CardSuit).Distinct().Count();

            var RankCount = cardlist.Select(y => y.CardRank).Distinct().Count();

            var PlayerHand = new HandInformation();

            var SuitCountMax = cardlist.Max(x => x.CardRank);

            //Flush
            if (SuitCount == 1)
            {
                PlayerHand.CardHand = CardHand.Flush;
                PlayerHand.CardRank = SuitCountMax;
                return PlayerHand;
            }
            //High Card
            if (RankCount == 5)
            {
                PlayerHand.CardHand = CardHand.HighCard;
                PlayerHand.CardRank = SuitCountMax;
            }

            //One Pair
            if (RankCount == 4)
            {
                var RankPairCount = cardlist.GroupBy(c => c.CardRank).Where(w => w.Count() == 2).Select(s => s.Key).Single();
                PlayerHand.CardHand = CardHand.OnePair;
                PlayerHand.CardRank = RankPairCount;
            }

            //One Pair
            if (RankCount == 3)
            {
                var RankPairCount = cardlist.GroupBy(c => c.CardRank).Where(w => w.Count() == 3).Select(s => s.Key).Single();
                PlayerHand.CardHand = CardHand.ThreeOfKind;
                PlayerHand.CardRank = RankPairCount;
            }

            return PlayerHand;
        }
    }
}
