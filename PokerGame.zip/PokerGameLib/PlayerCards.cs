﻿namespace PokerGame
{
    public class PlayerCards
    {
            public int RankId { get; set; }
            public string Rank { get; set; }
    }
}
