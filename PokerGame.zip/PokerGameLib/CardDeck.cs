﻿using PokerGame.Models;
using System;
using System.Collections.Generic;

namespace PokerGame
{
    public static class CardDeck
    {
        public static List<Card> ShuffleCards(List<Card> carddeck)
        {
            Random rnd = new Random();
            for (int i = 0; i < carddeck.Count; i++)
            {
                int k = rnd.Next(0, i);
                var value = carddeck[k];
                carddeck[k] = carddeck[i];
                carddeck[i] = value;
            }
            return carddeck;
        }
    }
}
