﻿using PokerGame.Enums;
using PokerGame.Models;
using System.Collections.Generic;

namespace PokerGame.Domain
{
    public class PokerPlayer
    {
        public string Name { get; set; }
        public List<Card> PokerHand { get; set; }
        public HandInformation HandInformation { get; set; }
        public PokerPlayer()
        {
            PokerHand = new List<Card>();
        }
    }
}
