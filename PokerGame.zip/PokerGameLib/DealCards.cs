﻿using PokerGame.Domain;
using PokerGame.Models;
using System.Collections.Generic;

namespace PokerGame
{
    public static class DealCards
    {
        public static void DealPlayerCards(List<PokerPlayer> players, List<Card> carddeck)
        {
            var carindex = 0;
            for (int i = 0; i < 5; i++)
            {
                foreach (var player in players)
                {
                    var card = carddeck[carindex];
                    player.PokerHand.Add(card);
                    carindex++;
                }
            }

        }
    }
}
