﻿using PokerGame.BusinessLogic;
using System;

namespace PokerGame
{
    class Program
    {
        static void Main(string[] args) {

            var pokerGameBusinessLogic = new PokerGameBusinessLogic();

            var pokerGame = new PokerGame(pokerGameBusinessLogic);

            pokerGame.AddPlayers("Connie");
            pokerGame.AddPlayers("James");
            pokerGame.AddPlayers("Reggie");
            pokerGame.AddPlayers("Doris");
            pokerGame.AddPlayers("Emmitt");

            var results = pokerGame.PlayGame();

            foreach (var result in results)
            {
                Console.WriteLine($"Winner: {result.Name} - {result.HandInformation.CardHand}");
                
                for (int i = 0; i < result.PokerHand.Count; i++)
                {
                    string rank = result.PokerHand[i].CardRank.ToString();
                    string suit = result.PokerHand[i].CardSuit.ToString();
                    Console.Write($"{rank}-{suit} ");
                    Console.WriteLine("");
                }
            }
            Console.ReadLine();
        }
    }
}
